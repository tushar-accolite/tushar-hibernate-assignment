package com.miniau.hibernet.model;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.*;


@Entity
@Table(name="personModel")
public class PersonModel {
	
	@Id
	@Column(name="person_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="personName")
	private String name;
	
	@Column(name ="phoneNo")
	private int phoneNo;
	@Column(name="address")
	private String add;
	
	@OneToMany(mappedBy="personModel")
	private Set<PhoneNumber> phoneNumber;
	public String getAdd() {
		return add;
	}


	public void setAdd(String add) {
		this.add = add;
	}


	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_Id")
	private Address address;
	
	@Column(name="createdAt")
//	@Temporal(TemporalType.TIMESTAMP)
	private Timestamp createdAt;
	
	@Column(name = "updatedAt")
//	@Temporal(TemporalType.TIMESTAMP)
	private Timestamp updatedAt;
	
	public PersonModel() {}
	

		public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	public Timestamp getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}


	public Timestamp getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

    
	public Set<PhoneNumber> getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(Set<PhoneNumber> phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	@Override
	public String toString() {
		return "PersonModel [id=" + id + ", name=" + name + ", phoneNo=" + phoneNo + ", add=" + add + ", phoneNumber="
				+ phoneNumber + ", address=" + address + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + "]";
	}


}
