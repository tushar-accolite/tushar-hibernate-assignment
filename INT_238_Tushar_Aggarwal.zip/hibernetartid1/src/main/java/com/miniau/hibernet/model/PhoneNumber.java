package com.miniau.hibernet.model;

import javax.persistence.*;

@Entity
@Table(name="phoneNumber")
public class PhoneNumber {
    
	@Id
	@Column(name="id")
	private long id;
	@Column(name="number")
    private String number;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="person_Id")
	private PersonModel person;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	public PersonModel getPerson() {
		return person;
	}
	public void setPerson(PersonModel person) {
		this.person = person;
	}
	@Override
	public String toString() {
		return "PhoneNumber [id=" + id + ", number=" + number + ", person=" + person + "]";
	}
	
}
