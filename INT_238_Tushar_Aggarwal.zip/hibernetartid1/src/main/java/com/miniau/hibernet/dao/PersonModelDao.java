package com.miniau.hibernet.dao;
import java.util.List;
import com.miniau.hibernet.model.PersonModel;

public interface PersonModelDao {
	public boolean save(PersonModel p);
	public List<PersonModel> getAllPerson();
	public boolean delete(int personId);
	public boolean update(PersonModel p);
	
}
