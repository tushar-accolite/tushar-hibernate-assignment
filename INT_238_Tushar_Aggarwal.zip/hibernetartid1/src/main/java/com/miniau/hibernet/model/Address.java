package com.miniau.hibernet.model;
import java.sql.Timestamp;

import javax.persistence.*;

import com.mysql.cj.xdevapi.Type;

@Entity
@Table(name = "address")
public class Address {
	
	@Id
	@Column(name="address_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
    
    @Column(name = "hNo")
    private int hNo;
    @Column(name = "streetNo")
	private int streetNo;
    @Column(name ="city")
	private String city;
    @Column(name ="pincode")
	private int pincode;
	@Column(name = "createdAt")
//	@Temporal(TemporalType.TIMESTAMP)
	private Timestamp createdAt;
	@Column(name ="updatedAt")
//	@Temporal(TemporalType.TIMESTAMP)
	private Timestamp updatedAt;
	
	public Address()
	{
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int gethNo() {
		return hNo;
	}

	public void sethNo(int hNo) {
		this.hNo = hNo;
	}

	public int getStreetNo() {
		return streetNo;
	}

	public void setStreetNo(int streetNo) {
		this.streetNo = streetNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", hNo=" + hNo + ", streetNo=" + streetNo + ", city=" + city + ", pincode="
				+ pincode + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + "]";
	}

}
