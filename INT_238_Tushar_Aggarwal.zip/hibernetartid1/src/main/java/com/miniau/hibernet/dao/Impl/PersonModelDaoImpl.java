package com.miniau.hibernet.dao.Impl;

import java.util.List;

import org.hibernate.*;

import com.miniau.hibernet.dao.PersonModelDao;
import com.miniau.hibernet.model.PersonModel;

public class PersonModelDaoImpl implements PersonModelDao {
	
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean save(PersonModel p) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		Transaction ts = session.beginTransaction();
		try {
		session.persist(p);
		}
		catch(HibernateException ex) {
			return false;
		}
		ts.commit();
		session.close();
		return true;
	}

	@SuppressWarnings("unchecked")
	public List<PersonModel> getAllPerson() {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		List<PersonModel> persons;
		try{
			 persons = session.createQuery("from PersonModel").list();
		}catch(HibernateException ex) {return null;}
		session.close();
		return persons;
	}

	public boolean delete(int personId) {
		Session session = this.sessionFactory.openSession();
		Transaction ts = session.beginTransaction();
		PersonModel p = (PersonModel)session.load(PersonModelDao.class,personId);
		try {
		if(p!=null)
		{
			session.delete(p);
		}
		}catch(HibernateException ex) {return false;}
		ts.commit();
		session.close();
		return true;
	} 

	public boolean update(PersonModel p) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		Transaction ts = session.beginTransaction();
		try{
			session.saveOrUpdate(p);
		}catch(HibernateException ex) 
		{
			return false;
		}
		ts.commit();
		session.close();
		return true;
	}

}