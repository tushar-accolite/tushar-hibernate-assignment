import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.miniau.hibernet.dao.PersonModelDao;
import com.miniau.hibernet.model.*;

public class MainHibernetUtility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("hibernet.xml");
		context.refresh();
		PersonModelDao personDao =context.getBean(PersonModelDao.class);
		
		PersonModel p = new PersonModel();
		p.setName("Tushar");
		p.setPhoneNo(72910834);
		p.setAdd("Greater Noida");
		Address address = new Address();
		address.sethNo(1);
		address.setPincode(110096);
		address.setStreetNo( 86);
		address.setCity("Greater Noida");
		p.setAddress(address);
		personDao.save(p);
        PhoneNumber phone1 = new PhoneNumber();
        PhoneNumber phone2 = new PhoneNumber();
        phone1.setNumber("7291040075");
        phone2.setNumber("9911144895");
        Set<PhoneNumber> phoneset = new HashSet<PhoneNumber>();
        phoneset.add(phone1);
        phoneset.add(phone2);
        p.setPhoneNumber(phoneset);
		List<PersonModel> persons= personDao.getAllPerson();
		for(PersonModel person : persons)
		{
			System.out.println(person.toString());
		}
        context.close();
	}

}
